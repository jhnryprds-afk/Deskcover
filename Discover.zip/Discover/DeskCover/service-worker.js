const CACHE_NAME = 'deskcover-discovery-v2';
const APP_SCOPE = self.registration.scope;
const APP_FILES = [
  new URL('customer/study-spaces.html', APP_SCOPE).href,
  new URL('customer/study-spaces.html?embedded=1', APP_SCOPE).href,
  new URL('js/discovery.js?v=2', APP_SCOPE).href
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('deskcover-discovery-') && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(fetch(event.request).then((response) => {
    if (response.ok) caches.open(CACHE_NAME).then((cache) => cache.put(event.request, response.clone()));
    return response;
  }).catch(async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    if (event.request.mode === 'navigate') return caches.match(APP_FILES[0]);
    return Response.error();
  }));
});