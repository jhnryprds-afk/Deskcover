document.addEventListener('DOMContentLoaded', () => {
  console.log('DeskCover loaded');
});
