document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');

  if (loginForm) {
    loginForm.addEventListener('submit', (event) => {
      event.preventDefault();

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();

      if (!email || !password) {
        alert('Please enter your email and password.');
        return;
      }

      alert('Login successful. Redirecting to dashboard...');
      window.location.href = 'customer/dashboard.html';
    });
  }

  const registerForm = document.getElementById('registerForm');

  if (registerForm) {
    registerForm.addEventListener('submit', (event) => {
      event.preventDefault();

      const fullName = document.getElementById('fullName').value.trim();
      const email = document.getElementById('regEmail').value.trim();
      const password = document.getElementById('regPassword').value.trim();
      const confirmPassword = document.getElementById('confirmPassword').value.trim();

      if (!fullName || !email || !password || !confirmPassword) {
        alert('Please complete all registration fields.');
        return;
      }

      if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
      }

      alert('Registration successful. Please login.');
      window.location.href = 'login.html';
    });
  }
});
