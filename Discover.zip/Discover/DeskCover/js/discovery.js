(() => {
  const embeddedMode = new URLSearchParams(location.search).get('embedded') === '1';
  if (embeddedMode) document.documentElement.classList.add('embedded');
  const fallbackLocation = { latitude: 14.6555, longitude: 121.0675, label: 'Near UP Diliman, Quezon City' };
  const locations = [
    { id: 'daily-grind', name: 'The Daily Grind', type: 'Cafe', price: 150, rating: 4.6, reviews: 120, lat: 14.6536, lon: 121.0685, open: 7, close: 22, noise: 'Moderate', seating: ['Solo', 'Group', 'Lounge'], purposes: ['Remote work', 'Casual work', 'Meetings'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms', 'Parking'], description: 'Bright neighborhood café with roomy tables and reliable Wi-Fi.', menu: [['Latte', '₱135'], ['Matcha', '₱160'], ['Croissant', '₱120']] },
    { id: 'study-nook', name: 'Study Nook Commons', type: 'Study Hub', price: 80, rating: 4.8, reviews: 86, lat: 14.6570, lon: 121.0630, open: 8, close: 23, noise: 'Quiet', seating: ['Solo', 'Group'], purposes: ['Quiet study', 'Remote work', 'Group work'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms'], description: 'Quiet individual desks plus bookable tables for study groups.', menu: [['Coffee', '₱75'], ['Iced tea', '₱65'], ['Sandwich', '₱110']] },
    { id: 'up-library', name: 'UP Diliman Main Library', type: 'Library', price: 0, rating: 4.7, reviews: 214, lat: 14.6566, lon: 121.0712, open: 8, close: 20, noise: 'Quiet', seating: ['Solo', 'Group'], purposes: ['Quiet study', 'Group work'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms'], description: 'Campus reading rooms, reference collections, and silent study floors.', menu: [['Coffee kiosk', '₱65'], ['Bottled water', '₱30'], ['Snack bar', '₱55']] },
    { id: 'workfolk', name: 'Workfolk Commons', type: 'Coworking Space', price: 250, rating: 4.5, reviews: 63, lat: 14.6420, lon: 121.0740, open: 7, close: 23, noise: 'Moderate', seating: ['Solo', 'Group', 'Lounge'], purposes: ['Remote work', 'Meetings', 'Group work'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms', 'Parking'], description: 'Flexible desks, meeting booths, and day passes for focused work.', menu: [['Espresso', '₱110'], ['Cold brew', '₱145'], ['Rice bowl', '₱190']] },
    { id: 'quiet-corner', name: 'Quiet Corner Reading Room', type: 'Library', price: 50, rating: 4.4, reviews: 37, lat: 14.6600, lon: 121.0620, open: 9, close: 21, noise: 'Quiet', seating: ['Solo'], purposes: ['Quiet study', 'Remote work'], amenities: ['Wi-Fi', 'Power outlets', 'Restrooms'], description: 'A calm reading room with individual desks and low-cost access.', menu: [['Tea', '₱50'], ['Coffee', '₱60'], ['Pastry', '₱85']] },
    { id: 'common-ground', name: 'Common Ground Café', type: 'Cafe', price: 180, rating: 4.3, reviews: 91, lat: 14.6514, lon: 121.0731, open: 6, close: 22, noise: 'Social', seating: ['Group', 'Lounge'], purposes: ['Casual work', 'Meetings', 'Group work'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms', 'Parking'], description: 'Social café with shared tables, brunch, and an all-day drinks menu.', menu: [['Iced Americano', '₱130'], ['Pancakes', '₱210'], ['Toastie', '₱175']] },
    { id: 'focus-commons', name: 'Focus Commons', type: 'Coworking Space', price: 300, rating: 4.9, reviews: 48, lat: 14.6500, lon: 121.0780, open: 8, close: 22, noise: 'Quiet', seating: ['Solo', 'Group'], purposes: ['Remote work', 'Meetings', 'Quiet study'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms', 'Parking'], description: 'A quiet coworking floor with monitor-ready desks and meeting rooms.', menu: [['Flat white', '₱150'], ['Salad bowl', '₱220'], ['Banana bread', '₱95']] },
    { id: 'kape-aral', name: "Kape't Aral", type: 'Cafe', price: 120, rating: 4.2, reviews: 54, lat: 14.6490, lon: 121.0590, open: 7, close: 21, noise: 'Moderate', seating: ['Solo', 'Group'], purposes: ['Quiet study', 'Casual work', 'Group work'], amenities: ['Wi-Fi', 'Power outlets', 'Air conditioning', 'Restrooms'], description: 'Student-friendly café with familiar merienda and plenty of outlets.', menu: [['Iced coffee', '₱110'], ['Pandesal set', '₱75'], ['Pasta', '₱160']] }
  ];
  const storage = {
    get(key, fallback) {
      try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
    }
  };
  let userLocation = storage.get('deskcover-user-location', fallbackLocation);
  let selectedCategory = 'all';
  let selectedRating = 5;
  let toastTimer;

  const byId = (id) => document.getElementById(id);
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  const distanceBetween = (latitude, longitude, place) => {
    const radians = (degrees) => degrees * Math.PI / 180;
    const latDelta = radians(place.lat - latitude);
    const lonDelta = radians(place.lon - longitude);
    const value = Math.sin(latDelta / 2) ** 2 + Math.cos(radians(latitude)) * Math.cos(radians(place.lat)) * Math.sin(lonDelta / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
  };
  const distanceFor = (place) => distanceBetween(userLocation.latitude, userLocation.longitude, place);
  const travelMinutes = (distance) => Math.max(1, Math.round(distance * 1.25 / 4.5 * 60));
  const hourLabel = (hour) => `${hour % 12 || 12} ${hour < 12 ? 'am' : 'pm'}`;
  const isOpen = (place) => {
    const now = new Date();
    const minutes = now.getHours() * 60 + now.getMinutes();
    return minutes >= place.open * 60 && minutes < place.close * 60;
  };
  const savedIds = () => storage.get('deskcover-saved-locations', []);
  const savedReviews = () => storage.get('deskcover-location-reviews', []);
  const userReviewsFor = (place) => savedReviews().filter((review) => review.locationId === place.id);
  const ratingFor = (place) => {
    const reviews = userReviewsFor(place);
    const count = place.reviews + reviews.length;
    const total = place.rating * place.reviews + reviews.reduce((sum, review) => sum + review.rating, 0);
    return { average: count ? total / count : 0, count };
  };

  function notify(message) {
    const toast = byId('toast');
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, 2800);
  }

  function createCard(place, includeMenu = true) {
    const distance = distanceFor(place);
    const rating = ratingFor(place);
    const open = isOpen(place);
    const saved = savedIds().includes(place.id);
    const menu = place.menu.map(([name, price]) => `<div class="menu-item">${escapeHTML(name)}<strong>${escapeHTML(price)}</strong></div>`).join('');
    const amenities = place.amenities.map((amenity) => `<span class="amenity">${escapeHTML(amenity)}</span>`).join('');
    return `<article class="space-card" data-place="${place.id}">
      <div class="space-content">
        <div class="space-heading"><div><h3>${escapeHTML(place.name)}</h3><span class="type-label">${escapeHTML(place.type)} · ${escapeHTML(place.purposes.join(' · '))}</span></div><span class="open-badge ${open ? '' : 'closed'}">${open ? 'Open now' : 'Closed'} · ${hourLabel(place.open)}–${hourLabel(place.close)}</span></div>
        <div class="rating-line"><span class="stars" aria-label="${rating.average.toFixed(1)} out of 5 stars">★</span><strong>${rating.average.toFixed(1)}</strong><span>(${rating.count} reviews)</span><span>·</span><span>Noise: ${escapeHTML(place.noise)}</span></div>
        <div class="details-line"><span><strong>${place.price ? `₱${place.price}` : 'Free'}</strong> / hour</span><span>${distance.toFixed(1)} km away</span><span>About ${travelMinutes(distance)} min walk</span></div>
        <div class="amenities">${amenities}</div>
        <div class="card-actions"><button class="button ${saved ? 'primary' : ''}" type="button" data-action="save" data-id="${place.id}" aria-pressed="${saved}">${saved ? 'Saved offline' : '☆ Save place'}</button><button class="button" type="button" data-action="review" data-id="${place.id}">Write a review</button><a class="button" href="https://www.openstreetmap.org/directions?engine=fossgis_osrm_foot&route=${userLocation.latitude}%2C${userLocation.longitude}%3B${place.lat}%2C${place.lon}" target="_blank" rel="noopener">Directions</a></div>
        ${includeMenu ? `<div class="menu-preview"><h4>Menu preview</h4><div class="menu-items">${menu}</div></div>` : ''}
      </div>
    </article>`;
  }

  function getFilteredPlaces() {
    const query = byId('search-input').value.trim().toLocaleLowerCase();
    const maxPrice = Math.min(Number(byId('max-price').value), Number(byId('budget-range').value));
    const maxDistance = Number(byId('max-distance').value);
    const purpose = byId('purpose-filter').value;
    const noise = byId('noise-filter').value;
    const seating = byId('seating-filter').value;
    const requiredAmenities = [...document.querySelectorAll('[data-amenity]:checked')].map((input) => input.dataset.amenity);
    return locations.filter((place) => {
      const searchable = [place.name, place.type, place.description, place.noise, ...place.purposes, ...place.amenities, ...place.menu.flat()].join(' ').toLocaleLowerCase();
      return (!query || searchable.includes(query)) && (selectedCategory === 'all' || place.type === selectedCategory) && place.price <= maxPrice && distanceFor(place) <= maxDistance && (purpose === 'all' || place.purposes.includes(purpose)) && (noise === 'all' || place.noise === noise) && (seating === 'all' || place.seating.includes(seating)) && requiredAmenities.every((amenity) => place.amenities.includes(amenity)) && (!byId('open-now').checked || isOpen(place));
    }).sort((first, second) => distanceFor(first) - distanceFor(second));
  }

  function render() {
    const filtered = getFilteredPlaces();
    const saved = locations.filter((place) => savedIds().includes(place.id));
    const budgetLimit = Number(byId('budget-range').value);
    const recommendations = locations.filter((place) => place.price <= budgetLimit).sort((first, second) => (second.rating - first.rating) || (distanceFor(first) - distanceFor(second))).slice(0, 3);
    byId('space-list').innerHTML = filtered.length ? filtered.map((place) => createCard(place)).join('') : '<div class="empty">No matching places. Try widening the distance or changing your filters.</div>';
    byId('results-count').textContent = `${filtered.length} ${filtered.length === 1 ? 'place' : 'places'} found`;
    byId('saved-list').innerHTML = saved.length ? saved.map((place) => createCard(place, false)).join('') : '<div class="empty">No saved places yet. Save a location to keep it available on this device.</div>';
    byId('saved-count').textContent = saved.length;
    byId('budget-list').innerHTML = recommendations.length ? recommendations.map((place) => createCard(place, false)).join('') : '<div class="empty">No locations fit this budget yet.</div>';
    byId('budget-count').textContent = `${recommendations.length} picks under ₱${budgetLimit}/hour`;
    renderReviewSummary();
  }

  function renderReviewSummary() {
    const reviews = savedReviews().slice().reverse();
    byId('review-list').innerHTML = reviews.length ? reviews.slice(0, 8).map((review) => {
      const place = locations.find((item) => item.id === review.locationId);
      return `<article class="review"><strong>${escapeHTML(review.name)}</strong> <span class="stars">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</span><span> · ${escapeHTML(place?.name || 'Location')}</span><p>${escapeHTML(review.text)}</p></article>`;
    }).join('') : '<div class="empty">No community reviews yet. Be the first to share one.</div>';
  }

  function renderLocationOptions() {
    byId('review-location').innerHTML = locations.map((place) => `<option value="${place.id}">${escapeHTML(place.name)}</option>`).join('');
  }

  function setLocation(latitude, longitude, label) {
    userLocation = { latitude, longitude, label };
    storage.set('deskcover-user-location', userLocation);
    byId('location-title').textContent = label;
    byId('location-status').textContent = 'Distances and walking times are estimated from your location.';
    render();
  }

  byId('locate-button').addEventListener('click', () => {
    if (!navigator.geolocation) {
      notify('Location is not available in this browser. Showing the Quezon City sample area.');
      return;
    }
    byId('location-status').textContent = 'Waiting for location permission…';
    navigator.geolocation.getCurrentPosition(({ coords }) => setLocation(coords.latitude, coords.longitude, 'Your current location'), () => {
      byId('location-title').textContent = 'Near UP Diliman, Quezon City';
      byId('location-status').textContent = 'Location permission was unavailable. Showing the sample area instead.';
      notify('Could not get your location. Showing the sample area.');
    }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 });
  });

  document.querySelectorAll('#category-tabs [data-category]').forEach((button) => button.addEventListener('click', () => {
    selectedCategory = button.dataset.category;
    document.querySelectorAll('#category-tabs .tab').forEach((tab) => tab.classList.toggle('active', tab === button));
    render();
  }));
  ['search-input', 'max-price', 'max-distance', 'purpose-filter', 'noise-filter', 'seating-filter', 'open-now'].forEach((id) => byId(id).addEventListener(id === 'search-input' ? 'input' : 'change', render));
  document.querySelectorAll('[data-amenity]').forEach((input) => input.addEventListener('change', render));
  byId('budget-range').addEventListener('input', () => {
    byId('budget-output').textContent = `Up to ₱${byId('budget-range').value} / hour`;
    render();
  });
  byId('filter-toggle').addEventListener('click', () => {
    const panel = byId('filter-panel');
    const expanded = byId('filter-toggle').getAttribute('aria-expanded') === 'true';
    panel.hidden = expanded;
    byId('filter-toggle').setAttribute('aria-expanded', String(!expanded));
  });
  const sidebar = byId('sidebar');
  const sidebarBackdrop = byId('sidebar-backdrop');
  const menuToggle = byId('menu-toggle');
  const closeSidebar = () => {
    sidebar.classList.remove('is-open');
    sidebarBackdrop.hidden = true;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open main menu');
  };
  menuToggle.addEventListener('click', () => {
    const open = !sidebar.classList.contains('is-open');
    sidebar.classList.toggle('is-open', open);
    sidebarBackdrop.hidden = !open;
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close main menu' : 'Open main menu');
  });
  sidebarBackdrop.addEventListener('click', closeSidebar);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeSidebar();
  });

  byId('saved-tab').addEventListener('click', () => byId('saved').scrollIntoView({ behavior: 'smooth' }));
  if (embeddedMode) {
    window.addEventListener('message', (event) => {
      if (event.origin === location.origin && event.data?.type === 'deskcover-discovery-scroll-top') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }
  document.querySelectorAll('.location-nav a').forEach((link) => link.addEventListener('click', () => {
    document.querySelectorAll('.location-nav a').forEach((item) => item.removeAttribute('aria-current'));
    link.setAttribute('aria-current', 'page');
    if (link.hash === '#reviews') {
      document.querySelectorAll('.sidebar .nav a').forEach((item) => item.removeAttribute('aria-current'));
      document.querySelector('.sidebar .nav a[href="#reviews"]').setAttribute('aria-current', 'page');
    } else if (link.hash === '#discover') {
      document.querySelectorAll('.sidebar .nav a').forEach((item) => item.removeAttribute('aria-current'));
      document.querySelector('.sidebar .nav a[href="#discover"]').setAttribute('aria-current', 'page');
    }
    closeSidebar();
  }));
  document.querySelectorAll('.sidebar .nav a').forEach((link) => link.addEventListener('click', () => {
    if (link.hash === '#discover' || link.hash === '#reviews') {
      document.querySelectorAll('.sidebar .nav a').forEach((item) => item.removeAttribute('aria-current'));
      link.setAttribute('aria-current', 'page');
      const locationTab = document.querySelector(`.location-nav a[href="${link.hash}"]`);
      if (locationTab) {
        document.querySelectorAll('.location-nav a').forEach((item) => item.removeAttribute('aria-current'));
        locationTab.setAttribute('aria-current', 'page');
      }
    }
    closeSidebar();
  }));

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    if (button.dataset.action === 'save') {
      const ids = savedIds();
      const updated = ids.includes(button.dataset.id) ? ids.filter((id) => id !== button.dataset.id) : [...ids, button.dataset.id];
      if (storage.set('deskcover-saved-locations', updated)) notify(updated.includes(button.dataset.id) ? 'Saved for offline access on this device.' : 'Removed from saved locations.');
      else notify('This browser could not save the location.');
      render();
    }
    if (button.dataset.action === 'review') {
      byId('review-location').value = button.dataset.id;
      byId('reviews').scrollIntoView({ behavior: 'smooth' });
      byId('review-text').focus({ preventScroll: true });
    }
  });

  byId('rating-input').innerHTML = Array.from({ length: 5 }, (_, index) => `<button type="button" data-rating="${index + 1}" aria-label="${index + 1} star${index ? 's' : ''}">★</button>`).join('');
  const paintRating = () => byId('rating-input').querySelectorAll('[data-rating]').forEach((star) => {
    const selected = Number(star.dataset.rating) <= selectedRating;
    star.classList.toggle('selected', selected);
    star.setAttribute('aria-pressed', String(selected));
  });
  byId('rating-input').addEventListener('click', (event) => {
    const star = event.target.closest('[data-rating]');
    if (star) { selectedRating = Number(star.dataset.rating); paintRating(); }
  });
  byId('review-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const text = byId('review-text').value.trim();
    if (!text) return;
    const reviews = savedReviews();
    reviews.push({ locationId: byId('review-location').value, rating: selectedRating, text, name: 'You', createdAt: new Date().toISOString() });
    if (!storage.set('deskcover-location-reviews', reviews)) {
      notify('This browser could not save your review.');
      return;
    }
    byId('review-form').reset();
    selectedRating = 5;
    paintRating();
    render();
    notify('Your review has been saved.');
  });

  if (userLocation?.latitude && userLocation?.longitude) {
    byId('location-title').textContent = userLocation.label || fallbackLocation.label;
    byId('location-status').textContent = userLocation.label === fallbackLocation.label ? 'Using the sample area. Allow location for nearby results.' : 'Distances and walking times are estimated from your saved location.';
  } else {
    userLocation = fallbackLocation;
  }
  renderLocationOptions();
  paintRating();
  render();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register('../service-worker.js').catch(() => notify('Offline caching is unavailable in this browser.'));
  }
})();