# DeskCover PH

A Philippine study-space and coffee ordering web app prototype for local workspace and café experiences.

## Pages

- Home: `index.html`
- Login: `login.html`
- Register: `register.html`
- Customer dashboard and modules under `customer/`
- Admin pages under `admin/`

## Folder structure

- `css/` for styles
- `js/` for scripts
- `assets/` for images and icons
